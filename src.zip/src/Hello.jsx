import React from "react";

const Hello = () => (<h1>Hello World!</h1>);

export default Hello;