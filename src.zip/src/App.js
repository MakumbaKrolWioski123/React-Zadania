import 'bootstrap/dist/css/bootstrap.css'; 
import React from 'react'; 
import './App.css';
import ItemList from './components/ItemList';
import ToggleText from './components/Toggle';
import Counter from './components/Counter';

function App() { 

    return ( 

        <div className="container mt-4"> 
            <ToggleText/> 
        </div> 

    ); 

} 

 

export default App; 
